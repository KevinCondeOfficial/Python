#Imports
import os
import random
import re
from re import A #necessary for checking for other files

# Variables
password = ""
username = ""
answer = 0
repeat = True
accountC = 0
accountName = ""
accountNum = 0
accountRoute = 0
numOfAcc = 0
income = 0
totalBal = 0
num = 0
#accounts = open("accounts.txt", "w") #W for overwrite, A for append, X for create, R for read
#accounts.close()

#Greeting message
#Company name: Central Bank Inc.
print("Central Bank Inc\n");
print("Hello welcome to your new central banking app!" )
print("Through our website you are able to access all your accounts in one place securely.\n")

#Initial account creation or login in
print("Would you like to:")
while (answer != 1 and answer != 2 and answer != 10):
    answer = int(input("(1) Create Account\n(2) Login\n(10) Exit\nChoice: "))
    print("")
    if (answer == 1):
        print("Let's create you an account.\nLet's start with a username: ")
        username = input("")
        while os.path.exists(username):
            print("Username already exists try a different one")
            username = input("Username: ")
        #accounts = open(username + ".txt", "w")
        os.mkdir(username)
        #accounts = open(username + ".txt", "x")
        #accounts.close()
        #accounts = open(username + ".txt", "w")
        print("Now lets make a password: ")
        password = input("")
        file_path = os.path.join(username, password)
        accounts = open(file_path, 'x')
        accounts.close()
        #accounts.write(password + "\n")
        #accounts = open(username + ".txt", "r")
        answer = 0
    elif (answer == 2):
        #New code to store info within folder and file
        username = input("Enter username: ")
        if os.path.exists(username):
            password = input("enter password: ")
            file_path = os.path.join(username, password)
            while (repeat == True):
                if os.path.isfile(file_path):
                    print("Successful login")
                    repeat = False
                else:
                    print("Login failed")
                    password = input("Incorrect password, try again: ")
                    file_path = os.path.join(username, password)

            print("")
            print("Welcome to your Central Account.\nWould you like to:")
            print("(1) See all accounts")
            print("(2) Add a new account")
            print("(3) Remove an account")
            print("(4) Check out budget plan")
            print("(5) Log out")
            accountC = int(input("Enter option: "))

            while (accountC != 1 and accountC != 2 and accountC != 3 and accountC != 4 and accountC !=5):
                accountC = int(input("Incorrect input try again: "))
            
            files = [f for f in os.listdir(username) if os.path.isfile(os.path.join(username, f))] #finds how many files are within the folder
            numOfAcc = len(files)
            
            if (accountC == 1):
                if (numOfAcc <= 1):    
                    print("Number of Accounts linked: " + str(numOfAcc))
                else: 
                    for x in range(1, numOfAcc): #need it to be string to iterate
                        file_path = os.path.join(username, "A" + str(x))
                        active = open(file_path, 'r')
                        print(active.read())
                        active.close()
            elif (accountC == 2):
                print("Link an Account.")
                accountName = input("Bank: ")
                accountNum = int(input("Account Number: "))
                accountRoute = int(input("Routing Number: "))

                file_path = os.path.join(username, "A" + str(numOfAcc))
                active = open(file_path, 'x')
                active.close()
                active = open(file_path, 'w')
                active.write("Account Name: " + accountName + "\n")
                active.write("Account Number: " + str(accountNum) + "\n")
                active.write("Routing Number: " + str(accountRoute) + "\n")
                active.write("Balance: " + str(random.randint(-10000, 10000)))
                active.close()
            elif (accountC == 3):
                print("Delete an Account.")
                accountName = input("Bank: ")
                accountNum = int(input("Account Number: "))
                accountRoute = int(input("Routing Number: "))

                file_path = os.path.join(username, "A" + str(numOfAcc - 1))
                active = open(file_path, 'r')
                lines = active.read().splitlines()
                if "Account Name: " + accountName in lines:
                    if "Account Number: " + str(accountNum) in lines:
                        if "Routing Number: " + str(accountRoute) in lines:
                            active.close()
                            os.remove(file_path)
                            print("Account deleted")
                        else:
                            print("Account not found")
                    else:
                        print("Account not found")
                else:
                    print("Account not found")
                active.close()
            elif (accountC == 4):
                print("Budget plan.")
                income = int(input("Annual Income: "))

                file_path = os.path.join(username, "A" + str(numOfAcc - 1))
                active = open(file_path, 'r')

                for x in range(1, numOfAcc-1):
                    lines = active.readlines() #Allows lines in file to be read seperately
                    line = lines[3] #Reads a specific line
                    digits = re.findall(r'\d', line) # Finds all numbers in line
                    num = int(''.join(digits)) #Turns array into an int
                    neg = re.findall(r'-', line) #Finds negative value within line
                    negTrue = ''.join(neg) #Turns array into string

                    if (negTrue == '-'): #Checks if balance is negative
                        totalBal += num - (2*num) #Makes balance negative
                    else:
                        totalBal += num

                print("Your total Balance along all accounts is: " + str(totalBal) + "\n")
                print("You earn " + str((income/12)*.85) + " dollars per month\n")
                if totalBal < 0:
                    print("You can pay off your balance in " + str(totalBal / (.2 * (income / 12) * .85)) + "months if you spend 20% of your income to pay it off.\nI believe in you!\n")
                else:
                    print("You have a positive balance.\nGood Job!")

                active.close()
            elif (accountC == 5):
                print("Have a great day\n")

            #Original code to store info within File
            #with open(username) as file:
                #lines = file.read().splitlines()
                #if password in lines:
                   #print("value found ")
                    #print(accounts.read())
        else:
            print("Username not found try again")
        answer = 0
    elif (answer == 10):
        print("Enjoy your day")
    else:
        print("incorrect input")
