#Imports
import os
import array
import random #Allows for random number generation
import re
from re import A #necessary for checking for other files

#Variables
inChoice = 0
repeat = True
items = ["Banana", "BananaPudding", "BananaSoap"]
stock = ""
itemChoice = 0
quan = 0
banana = 2.99
bananaPud = 5.99
bananaSoap = 9.99 
total = 0.0

#Intro
print("Hello Welcome to Banana Emporium\n")
print("Here you can buy many different types of banana products.\n")

#Main
while (repeat == True):
    #Initial Choice
    print("Would you like to:")
    print("(1) Purchase")
    print("(2) Return")
    print("(3) Inventory")
    print("(4) Report")
    print("(5) Exit")
    inChoice = int(input("Choice: "))

    if (inChoice == 1):
        print("\nPurchase\n")
        print("We have many different items for sale such as:")

        #items for sale
        for x in range(0, len(items)):
            itemStock = open(items[x] + ".txt", "r")
            lines = itemStock.readlines()
            stock = lines[0] + lines[1]
            print("(" + str(x+1) + ") " + items[x])
            print(stock)
            itemStock.close()

        #ITEMS 
        #region
        itemChoice = int(input("What item do you want: "))
        if (itemChoice == 1 or itemChoice == 2 or itemChoice == 3):
            quan = int(input("Quantity: "))

        if (itemChoice == 1):
            itemStock = open(items[itemChoice - 1] + ".txt", "r")
            lines = itemStock.readlines()
            if (quan <= int(lines[1])):
                total = quan * banana
                print("\ntotal: " + str(total))
                lines[1] = str(int(lines[1]) - quan) + "\n" #Modifies quantity instock
                lines[3] = str(int(lines[3]) + quan) + "\n"
                itemStock = open(items[itemChoice - 1] + ".txt", "w")
                for x in range(4):
                    itemStock.write(lines[x])
            itemStock.close()
        elif (itemChoice == 2):
            itemStock = open(items[itemChoice - 1] + ".txt", "r")
            lines = itemStock.readlines()
            if (quan <= int(lines[1])):
                total = quan * bananaPud
                print("\ntotal: " + str(total))
                lines[1] = str(int(lines[1]) - quan) + "\n" #Modifies quantity instock
                lines[3] = str(int(lines[3]) + quan) + "\n"
                itemStock = open(items[itemChoice - 1] + ".txt", "w")
                for x in range(4):
                    itemStock.write(lines[x])
            itemStock.close()
        elif (itemChoice == 3):
            itemStock = open(items[itemChoice - 1] + ".txt", "r")
            lines = itemStock.readlines()
            if (quan <= int(lines[1])):
                total = quan * bananaSoap
                print("\ntotal: " + str(total))
                lines[1] = str(int(lines[1]) - quan) + "\n" #Modifies quantity instock
                lines[3] = str(int(lines[3]) + quan) + "\n"
                itemStock = open(items[itemChoice - 1] + ".txt", "w")
                for x in range(4):
                    itemStock.write(lines[x])
            itemStock.close()
        
        if(quan <= int(lines[1])):
            print("Thank you for your purchase!\n")
        else:
            print("We are out of that item sorry comeback next time!")

        itemChoice = 0
        #endregion

        inChoice = 0
    elif (inChoice == 2):
        print("\nRefund\n") 
        print("What would you like to return:")

        #Display Items
        for x in range(0, len(items)):
            print("(" + str(x+1) + ") " + items[x])

        #ITEMS for Return
        #region
        itemChoice = int(input("What item: "))
        if (itemChoice == 1 or itemChoice == 2 or itemChoice == 3):
            quan = int(input("Quantity: "))

        if (itemChoice == 1):
            itemStock = open(items[itemChoice - 1] + ".txt", "r")
            lines = itemStock.readlines()
            if (quan <= int(lines[3])):
                total = quan * banana
                print("\ntotal return: " + str(total))
                lines[1] = str(int(lines[1]) + quan) + "\n" #Modifies quantity instock
                lines[3] = str(int(lines[3]) - quan) + "\n"
                itemStock = open(items[itemChoice - 1] + ".txt", "w")
                for x in range(4):
                    itemStock.write(lines[x])
            itemStock.close()
        elif (itemChoice == 2):
            itemStock = open(items[itemChoice - 1] + ".txt", "r")
            lines = itemStock.readlines()
            if (quan <= int(lines[3])):
                total = quan * bananaPud
                print("\ntotal return: " + str(total))
                lines[1] = str(int(lines[1]) + quan) + "\n" #Modifies quantity instock
                lines[3] = str(int(lines[3]) - quan) + "\n"
                itemStock = open(items[itemChoice - 1] + ".txt", "w")
                for x in range(4):
                    itemStock.write(lines[x])
            itemStock.close()
        elif (itemChoice == 3):
            itemStock = open(items[itemChoice - 1] + ".txt", "r")
            lines = itemStock.readlines()
            if (quan <= int(lines[3])):
                total = quan * bananaSoap
                print("\ntotal: " + str(total))
                lines[1] = str(int(lines[1]) + quan) + "\n" #Modifies quantity instock
                lines[3] = str(int(lines[3]) - quan) + "\n"
                itemStock = open(items[itemChoice - 1] + ".txt", "w")
                for x in range(4):
                    itemStock.write(lines[x])
            itemStock.close()
         
        if (quan <= int(lines[3])):
            print("Thank you for your return!\n")
        else:
            print("We can not process your refund right now!")

        itemChoice = 0
        #endregion

        inChoice = 0
    elif (inChoice == 3):
        print("\nInventory\n")

        #inventory
        for x in range(0, len(items)):
            itemStock = open(items[x] + ".txt", "r")
            lines = itemStock.readlines()
            stock = lines[0] + lines[1] + lines[2] + lines[3]
            print("(" + str(x+1) + ") " + items[x])
            print(stock)
            itemStock.close()

        #ITEMS 
        #region
        itemChoice = int(input("What item do you want to restock: "))
        if (itemChoice == 1 or itemChoice == 2 or itemChoice == 3):
            quan = int(input("Quantity: "))

        if (itemChoice == 1):
            itemStock = open(items[itemChoice - 1] + ".txt", "r")
            lines = itemStock.readlines()
            lines[1] = str(int(lines[1]) + quan) + "\n" #Modifies quantity instock
            itemStock = open(items[itemChoice - 1] + ".txt", "w")
            for x in range(4):
                itemStock.write(lines[x])
            itemStock.close()
        elif (itemChoice == 2):
            itemStock = open(items[itemChoice - 1] + ".txt", "r")
            lines = itemStock.readlines()
            lines[1] = str(int(lines[1]) + quan) + "\n" #Modifies quantity instock
            itemStock = open(items[itemChoice - 1] + ".txt", "w")
            for x in range(4):
                itemStock.write(lines[x])
            itemStock.close()
        elif (itemChoice == 3):
            itemStock = open(items[itemChoice - 1] + ".txt", "r")
            lines = itemStock.readlines()
            lines[1] = str(int(lines[1]) + quan) + "\n" #Modifies quantity instock
            itemStock = open(items[itemChoice - 1] + ".txt", "w")
            for x in range(4):
                itemStock.write(lines[x])
            itemStock.close()
        
        if(quan <= int(lines[1])):
            print("Thank you for your purchase!\n")
        else:
            print("We are out of that item sorry comeback next time!")

        itemChoice = 0
        #endregion


        inChoice = 0
    elif (inChoice == 4):
        print("\nReport\n")

        #Report
        for x in range(0, len(items)):
            itemStock = open(items[x] + ".txt", "r")
            lines = itemStock.readlines()
            stock = lines[2] + lines[3]
            if (x == 0):
                price = banana
                total = int(lines[3]) * banana
            elif (x == 1):
                price = bananaPud
                total = int(lines[3]) * bananaPud
            elif (x == 2):
                price = bananaSoap
                total = int(lines[3]) * bananaSoap
            print("(" + str(x+1) + ") " + items[x])
            print("Price per unit: " + str(price))
            print(stock)
            print("total: " + str(total))
            itemStock.close()

        

        inChoice = 0
    elif (inChoice == 5):
        #Exit Code, gives a fair well and stops while statement
        print("Have a Great Day")
        repeat = False
    else:
        #Error Handling
        print("Invalid option! Try again")

#.count("x") ; Counts the number of times x appears within an array